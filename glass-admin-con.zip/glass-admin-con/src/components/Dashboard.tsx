import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../styles/dashboard.css';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [isDarkMode, setIsDarkMode] = useState(true);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'light') {
      setIsDarkMode(false);
      document.body.classList.remove('dark-mode');
      document.body.classList.add('light-mode');
    } else {
      setIsDarkMode(true);
      document.body.classList.add('dark-mode');
      document.body.classList.remove('light-mode');
    }
  }, []);

  const handleThemeToggle = () => {
    setIsDarkMode(!isDarkMode);
    if (isDarkMode) {
      document.body.classList.remove('dark-mode');
      document.body.classList.add('light-mode');
      localStorage.setItem('theme', 'light');
    } else {
      document.body.classList.remove('light-mode');
      document.body.classList.add('dark-mode');
      localStorage.setItem('theme', 'dark');
    }
  };

  const stats = [
    { title: 'Total Revenue', value: '$84,254', change: '+12.5%', icon: 'revenue', positive: true },
    { title: 'Active Users', value: '24,521', change: '+8.2%', icon: 'users', positive: true },
    { title: 'Total Orders', value: '8,461', change: '-3.1%', icon: 'orders', positive: false },
    { title: 'Conversion Rate', value: '3.24%', change: '+2.4%', icon: 'conversion', positive: true },
  ];

  const chartData = [
    { month: 'Jan', value: 120 },
    { month: 'Feb', value: 160 },
    { month: 'Mar', value: 90 },
    { month: 'Apr', value: 140 },
    { month: 'May', value: 180 },
    { month: 'Jun', value: 130 },
    { month: 'Jul', value: 170 },
    { month: 'Aug', value: 150 },
    { month: 'Sep', value: 190 },
    { month: 'Oct', value: 140 },
    { month: 'Nov', value: 175 },
    { month: 'Dec', value: 200 },
  ];

  const activities = [
    { user: 'John Doe', action: 'purchased Premium Plan', time: '2 minutes ago', initials: 'JD' },
    { user: 'Anna Smith', action: 'submitted a support ticket', time: '15 minutes ago', initials: 'AS' },
    { user: 'Mike Johnson', action: 'upgraded subscription', time: '1 hour ago', initials: 'MJ' },
    { user: 'Emily White', action: 'completed onboarding', time: '2 hours ago', initials: 'EW' },
    { user: 'Robert Brown', action: 'requested refund', time: '3 hours ago', initials: 'RB' },
  ];

  const transactions = [
    { customer: 'John Doe', email: 'john@example.com', product: 'Premium Plan', date: 'Jan 15, 2025', status: 'completed', amount: '$299.00', initials: 'JD' },
    { customer: 'Anna Smith', email: 'anna@example.com', product: 'Enterprise License', date: 'Jan 14, 2025', status: 'processing', amount: '$1,499.00', initials: 'AS' },
    { customer: 'Mike Johnson', email: 'mike@example.com', product: 'Team Bundle', date: 'Jan 13, 2025', status: 'completed', amount: '$599.00', initials: 'MJ' },
    { customer: 'Emily White', email: 'emily@example.com', product: 'Starter Plan', date: 'Jan 12, 2025', status: 'pending', amount: '$49.00', initials: 'EW' },
    { customer: 'Robert Brown', email: 'robert@example.com', product: 'Pro Annual', date: 'Jan 11, 2025', status: 'completed', amount: '$199.00', initials: 'RB' },
  ];

  const progressItems = [
    { label: 'UI Design', value: 85 },
    { label: 'Backend API', value: 62 },
    { label: 'Testing', value: 45 },
    { label: 'Documentation', value: 28 },
  ];

  const getMaxValue = () => Math.max(...chartData.map(d => d.value));

  return (
    <div className="dashboard">
      {/* Animated Background */}
      <div className="background"></div>
      <div className="orb orb-1"></div>
      <div className="orb orb-2"></div>
      <div className="orb orb-3"></div>

      {/* Sidebar */}
      <aside className={`sidebar ${sidebarOpen ? 'open' : ''}`}>
        <div className="sidebar-header">
          <div className="logo">G</div>
          <span className="logo-text">GlassDash</span>
        </div>

        <ul className="nav-menu">
          <li className="nav-section">
            <span className="nav-section-title">Main Menu</span>
            <ul>
              <li className="nav-item">
                <a href="#" className="nav-link active">
                  <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <rect x="3" y="3" width="7" height="7" rx="1"/>
                    <rect x="14" y="3" width="7" height="7" rx="1"/>
                    <rect x="3" y="14" width="7" height="7" rx="1"/>
                    <rect x="14" y="14" width="7" height="7" rx="1"/>
                  </svg>
                  Dashboard
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M12 2L2 7l10 5 10-5-10-5z"/>
                    <path d="M2 17l10 5 10-5"/>
                    <path d="M2 12l10 5 10-5"/>
                  </svg>
                  Analytics
                  <span className="nav-badge">New</span>
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                    <circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
                    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                  </svg>
                  Users
                </a>
              </li>
              <li className="nav-item">
                <a href="#" className="nav-link">
                  <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="12" cy="12" r="3"/>
                    <path d="M12 1v6m0 6v6M4.22 4.22l4.24 4.24m5.08 5.08l4.24 4.24M1 12h6m6 0h6M4.22 19.78l4.24-4.24m5.08-5.08l4.24-4.24"/>
                  </svg>
                  Settings
                </a>
              </li>
            </ul>
          </li>

          <li className="nav-section">
            <span className="nav-section-title">Account</span>
            <ul>
              <li className="nav-item">
                <a href="#" onClick={(e) => { e.preventDefault(); navigate('/'); }} className="nav-link">
                  <svg className="nav-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
                    <polyline points="16 17 21 12 16 7"/>
                    <line x1="21" y1="12" x2="9" y2="12"/>
                  </svg>
                  Logout
                </a>
              </li>
            </ul>
          </li>
        </ul>

        <div className="sidebar-footer">
          <div className="user-profile">
            <div className="user-avatar">TM</div>
            <div className="user-info">
              <div className="user-name">TemplateMo</div>
              <div className="user-role">Administrator</div>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <polyline points="6 9 12 15 18 9"/>
            </svg>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="main-content">
        {/* Top Navbar */}
        <nav className="navbar">
          <h1 className="page-title">Dashboard Overview</h1>
          <div className="navbar-right">
            <div className="search-box">
              <svg className="search-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <circle cx="11" cy="11" r="8"/>
                <line x1="21" y1="21" x2="16.65" y2="16.65"/>
              </svg>
              <input type="text" className="search-input" placeholder="Search anything..." />
            </div>
            <button className="nav-btn">
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/>
                <path d="M13.73 21a2 2 0 0 1-3.46 0"/>
              </svg>
              <span className="notification-dot"></span>
            </button>
            <button className="nav-btn" onClick={handleThemeToggle}>
              <svg className="icon-sun" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ display: isDarkMode ? 'block' : 'none' }}>
                <circle cx="12" cy="12" r="4"/>
                <path d="M12 2v2"/><path d="M12 20v2"/>
                <path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/>
                <path d="M2 12h2"/><path d="M20 12h2"/>
                <path d="M6.34 17.66l-1.41 1.41"/><path d="M19.07 4.93l-1.41 1.41"/>
              </svg>
              <svg className="icon-moon" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ display: !isDarkMode ? 'block' : 'none' }}>
                <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
              </svg>
            </button>
          </div>
        </nav>

        {/* Stats Grid */}
        <section className="stats-grid">
          {stats.map((stat, idx) => (
            <div key={idx} className="glass-card glass-card-3d stat-card">
              <div className="stat-card-inner">
                <div className="stat-info">
                  <h3>{stat.title}</h3>
                  <div className="stat-value">{stat.value}</div>
                  <span className={`stat-change ${stat.positive ? 'positive' : 'negative'}`}>
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <polyline points={stat.positive ? "23 6 13.5 15.5 8.5 10.5 1 18" : "23 18 13.5 8.5 8.5 13.5 1 6"}/>
                    </svg>
                    {stat.change}
                  </span>
                </div>
                <div className={`stat-icon ${stat.icon}`}>
                  {stat.icon === 'revenue' && <svg viewBox="0 0 24 24" fill="none" stroke="var(--emerald-light)" strokeWidth="2"><line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>}
                  {stat.icon === 'users' && <svg viewBox="0 0 24 24" fill="none" stroke="var(--gold)" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>}
                  {stat.icon === 'orders' && <svg viewBox="0 0 24 24" fill="none" stroke="var(--coral)" strokeWidth="2"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>}
                  {stat.icon === 'conversion' && <svg viewBox="0 0 24 24" fill="none" stroke="var(--success)" strokeWidth="2"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></svg>}
                </div>
              </div>
            </div>
          ))}
        </section>

        {/* Content Grid */}
        <section className="content-grid">
          {/* Chart Card */}
          <div className="glass-card chart-card">
            <div className="card-header">
              <div>
                <h2 className="card-title">Revenue Analytics</h2>
                <p className="card-subtitle">Monthly revenue overview</p>
              </div>
              <div className="card-actions">
                <button className="card-btn active">Monthly</button>
                <button className="card-btn">Weekly</button>
                <button className="card-btn">Daily</button>
              </div>
            </div>
            <div className="chart-wrapper">
              <div className="chart-container">
                <div className="chart-y-axis">
                  <span className="y-value">$100K</span>
                  <span className="y-value">$80K</span>
                  <span className="y-value">$60K</span>
                  <span className="y-value">$40K</span>
                  <span className="y-value">$20K</span>
                  <span className="y-value">$0</span>
                </div>
                <div className="chart-placeholder">
                  {chartData.map((data, idx) => (
                    <div key={idx} className="chart-bar-group">
                      <div
                        className={`chart-bar bar-${['emerald', 'gold', 'coral', 'teal', 'amber'][idx % 5]}`}
                        style={{ height: `${(data.value / getMaxValue()) * 200}px` }}
                      ></div>
                      <span className="chart-label">{data.month}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Activity Feed */}
          <div className="glass-card activity-card">
            <div className="card-header">
              <div>
                <h2 className="card-title">Recent Activity</h2>
                <p className="card-subtitle">Latest transactions</p>
              </div>
            </div>
            <div className="activity-list">
              {activities.map((activity, idx) => {
                const gradients = [
                  'linear-gradient(135deg, var(--emerald-light), var(--emerald))',
                  'linear-gradient(135deg, var(--gold), var(--amber))',
                  'linear-gradient(135deg, var(--coral), var(--gold))',
                  'linear-gradient(135deg, var(--success), var(--emerald))',
                  'linear-gradient(135deg, var(--amber), var(--gold))'
                ];
                return (
                  <div key={idx} className="activity-item">
                    <div className="activity-avatar" style={{ background: gradients[idx] }}>{activity.initials}</div>
                    <div className="activity-content">
                      <p className="activity-text"><strong>{activity.user}</strong> {activity.action}</p>
                      <span className="activity-time">{activity.time}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Data Table */}
          <div className="glass-card table-card">
            <div className="card-header">
              <div>
                <h2 className="card-title">Recent Transactions</h2>
                <p className="card-subtitle">Latest orders and payments</p>
              </div>
              <div className="card-actions">
                <button className="card-btn">View All</button>
                <button className="card-btn">Export</button>
              </div>
            </div>
            <div className="table-wrapper">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Customer</th>
                    <th>Product</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Amount</th>
                  </tr>
                </thead>
                <tbody>
                  {transactions.map((tx, idx) => {
                    const gradients = [
                      'linear-gradient(135deg, var(--emerald-light), var(--emerald))',
                      'linear-gradient(135deg, var(--gold), var(--amber))',
                      'linear-gradient(135deg, var(--success), var(--emerald))',
                      'linear-gradient(135deg, var(--coral), var(--gold))',
                      'linear-gradient(135deg, var(--emerald), var(--gold))'
                    ];
                    return (
                      <tr key={idx}>
                        <td>
                          <div className="table-user">
                            <div className="table-avatar" style={{ background: gradients[idx] }}>{tx.initials}</div>
                            <div className="table-user-info">
                              <span className="table-user-name">{tx.customer}</span>
                              <span className="table-user-email">{tx.email}</span>
                            </div>
                          </div>
                        </td>
                        <td>{tx.product}</td>
                        <td>{tx.date}</td>
                        <td><span className={`status-badge ${tx.status}`}>{tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}</span></td>
                        <td><span className="table-amount">{tx.amount}</span></td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </section>

        {/* Bottom Grid */}
        <section className="bottom-grid">
          {/* Calendar Widget */}
          <div className="glass-card">
            <div className="calendar-header">
              <h2 className="card-title">January 2025</h2>
              <div className="calendar-nav">
                <button className="calendar-nav-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="15 18 9 12 15 6"/></svg></button>
                <button className="calendar-nav-btn"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><polyline points="9 18 15 12 9 6"/></svg></button>
              </div>
            </div>
            <div className="calendar-grid">
              <span className="calendar-day-name">Sun</span><span className="calendar-day-name">Mon</span><span className="calendar-day-name">Tue</span>
              <span className="calendar-day-name">Wed</span><span className="calendar-day-name">Thu</span><span className="calendar-day-name">Fri</span><span className="calendar-day-name">Sat</span>
              {/* Previous month days */}
              <span className="calendar-day other-month">29</span><span className="calendar-day other-month">30</span><span className="calendar-day other-month">31</span>
              {/* Current month */}
              {[...Array(31)].map((_, i) => (
                <span key={i} className={`calendar-day ${i === 0 ? 'today' : ''}`}>{i + 1}</span>
              ))}
              {/* Next month days */}
              <span className="calendar-day other-month">1</span>
            </div>
          </div>

          {/* Donut Chart */}
          <div className="glass-card">
            <div className="card-header">
              <div>
                <h2 className="card-title">Traffic Sources</h2>
                <p className="card-subtitle">User acquisition breakdown</p>
              </div>
            </div>
            <div className="donut-container">
              <div className="donut-chart">
                <svg width="160" height="160" viewBox="0 0 140 140">
                  <circle className="donut-bg" cx="70" cy="70" r="54"/>
                  <circle className="donut-segment" cx="70" cy="70" r="54" stroke="var(--emerald-light)" strokeDasharray="169.6 339.3" strokeDashoffset="0"/>
                  <circle className="donut-segment" cx="70" cy="70" r="54" stroke="var(--gold)" strokeDasharray="101.8 339.3" strokeDashoffset="-169.6"/>
                  <circle className="donut-segment" cx="70" cy="70" r="54" stroke="var(--coral)" strokeDasharray="67.9 339.3" strokeDashoffset="-271.4"/>
                </svg>
                <div className="donut-center">
                  <div className="donut-value">24.5K</div>
                  <div className="donut-label">Visitors</div>
                </div>
              </div>
              <div className="donut-legend">
                <div className="legend-item"><span className="legend-color cyan"></span><span>Organic Search (50%)</span></div>
                <div className="legend-item"><span className="legend-color magenta"></span><span>Social Media (30%)</span></div>
                <div className="legend-item"><span className="legend-color purple"></span><span>Direct Traffic (20%)</span></div>
              </div>
            </div>
          </div>

          {/* Progress Card */}
          <div className="glass-card progress-card">
            <div className="card-header">
              <div>
                <h2 className="card-title">Project Progress</h2>
                <p className="card-subtitle">Current sprint status</p>
              </div>
            </div>
            {progressItems.map((item, idx) => (
              <div key={idx} className="progress-item">
                <div className="progress-header">
                  <span className="progress-label">{item.label}</span>
                  <span className="progress-value">{item.value}%</span>
                </div>
                <div className="progress-bar">
                  <div
                    className={`progress-fill ${['cyan', 'magenta', 'purple', 'cyan'][idx]}`}
                    style={{ width: `${item.value}%` }}
                  ></div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>

      {/* Mobile Menu Toggle */}
      <button className="mobile-menu-toggle" onClick={() => setSidebarOpen(!sidebarOpen)}>
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
          <line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
      </button>
    </div>
  );
};

export default Dashboard;
